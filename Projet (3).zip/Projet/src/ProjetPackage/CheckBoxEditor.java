
package ProjetPackage;

import java.awt.Component;
import javax.swing.AbstractCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;

class CheckBoxEditor extends AbstractCellEditor implements TableCellEditor {

  JCheckBox checkBox;

  public CheckBoxEditor(JCheckBox checkBox) {
    this.checkBox = checkBox;
  }

  @Override
  public Object getCellEditorValue() {
    return checkBox.isSelected();
  }

  @Override
  public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
    checkBox.setSelected((value != null && (Boolean) value));
    return checkBox;
  }
}
