
package ProjetPackage;

import java.awt.Component;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author chafi
 */
public class CheckBoxRenderer extends DefaultTableCellRenderer {

  @Override
  public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
    JCheckBox checkBox = new JCheckBox();
    checkBox.setSelected((value != null && (Boolean) value));
    return checkBox;
  }

    
}
