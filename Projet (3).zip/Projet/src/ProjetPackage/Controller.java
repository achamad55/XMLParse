
package ProjetPackage;

import java.awt.List;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JCheckBox;
import javax.swing.table.DefaultTableModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Controller implements Subject {
    
        Model model = new Model();
            
        public DefaultTableModel tableModel = model.getModel();
        
         ArrayList<Observer> observers = new ArrayList<>();

    @Override
    public void registerObserver(Observer o) {
        observers.add(o);
    }

    @Override
    public void removeObserver(Observer o) {
        observers.remove(o);
    }

    @Override
    public void notifyObservers() {
        for (Observer o : observers) {
            o.update();
    }
    }
    


  public void parser() throws SAXException {
      
      
    notifyObservers();
 
    String urlString = "https://www.teluq.ca/site/infos/rss/communiques.php";

    try {

      DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
      DocumentBuilder db = dbf.newDocumentBuilder();
      tableModel.addColumn("Title");
      tableModel.addColumn("Link");
      tableModel.addColumn("GUID");
      tableModel.addColumn("PubDate");
      tableModel.addColumn("Description");
      tableModel.addColumn("Selected");

                   
        try ( 
                InputStream inputStream = new URL(urlString).openStream()) {
            Document doc = db.parse(inputStream);

            NodeList nodeList = doc.getElementsByTagName("item");

            for (int i = 1; i < nodeList.getLength(); i++) {
                Element item = (Element) nodeList.item(i);
                String title = item.getElementsByTagName("title").item(0).getTextContent();
                String link = item.getElementsByTagName("link").item(0).getTextContent();
                String guid = item.getElementsByTagName("guid").item(0).getTextContent();
                String pubDate = item.getElementsByTagName("pubDate").item(0).getTextContent();
                String description = item.getElementsByTagName("description").item(0).getTextContent();
                Boolean selected = false; 

                
                System.out.println("title: " + title);
                System.out.println("Link: " + link);
                System.out.println("GUID: " + guid);
                System.out.println("PubDate: " + pubDate);
                System.out.println("Description: " + description);
                
                Object[] rowData = { title, link, guid, pubDate, description, selected};
                tableModel.addRow(rowData);
                

            }

        }
       

    } catch (ParserConfigurationException | IOException e) {

    }
  }
  
  public DefaultTableModel getTableModel() {
  return tableModel;
  }
 
public void enregistrerFlux() {
  try {

      FileWriter writer = new FileWriter("table.txt");

      int numRows = tableModel.getRowCount();
      int numCols = tableModel.getColumnCount();

      for (int i = 0; i < numRows; i++) {
        for (int j = 0; j < numCols; j++) {
          Object value = tableModel.getValueAt(i, j);
          writer.write(value + ",\n");
        }
        writer.write("\n");
      }

      writer.close();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
}

  
public void supprimer() {
    
        for (int i = tableModel.getRowCount() - 1; i >= 0; i--) {

            boolean isSelected = (boolean) tableModel.getValueAt(i, 5);

            if (isSelected) {
                tableModel.removeRow(i);
            }
        }
}

    void setTableModel(DefaultTableModel previousTableModel) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

 
}
    

  
