
package ProjetPackage;

import java.awt.Component;
import javax.swing.JButton;


class Leaf extends Component {
    
  private JButton button;

  public Leaf(JButton button) {
    this.button = button;
  }

  public void Operation() {
    button.setVisible(true);
  }
}
