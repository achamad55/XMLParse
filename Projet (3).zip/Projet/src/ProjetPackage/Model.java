
package ProjetPackage;

import javax.swing.table.DefaultTableModel;

public class Model {
    
    public DefaultTableModel tableModel = new DefaultTableModel();
    
    public DefaultTableModel getModel() {
    return tableModel;
    }
    
    public void setModel(DefaultTableModel Model) {
    this.tableModel = Model;
    }
}
