
package ProjetPackage;

interface Observer {
    
    public void update ();
}