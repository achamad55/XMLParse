
package ProjetPackage;

interface Template {
    
    public void templateMethod();
    void step1();
    void step2();
    void step3();
}
    

